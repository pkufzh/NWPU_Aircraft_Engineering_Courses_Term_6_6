disp('- program start -')
main
%diary off