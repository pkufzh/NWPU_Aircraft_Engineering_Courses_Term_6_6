function [out]=fThrustLapse(state);
out=(state.rho/1.225)^0.9